# EcoCapture 検証記録

## 2026-09-05 / 0.3.7 UX250h実車・Pi 4B移植準備版

- MZAH10実車で0 rpm、作動中976～1329 rpm、停止遷移をUSBストリームで確認。OBD要求1935、応答1932、TXエラー0、faultなし。
- Pi 4B用ARM64配布へ、aarch64・画面・実行権限・USB権限を検査するランチャーと、VID/PID限定udevルールを同梱。
- Compatibility renderer + OpenGL ES 3.0をPi用ランチャーで指定。通常データは`$HOME/.config/EcoCapture`に分離し、アプリ本体をroot実行しない構成。
- Windows x64とLinux ARM64を同一ソースから再生成し、ARM64 ELF、同梱.NET、ZIP CRC、Pi用ファイルを監査する。
- 96項目のWindowsビルド前試験、Linux x86_64実環境101項目、Web 9項目、配布監査を合格。Windows ZIPは82,189,136 bytes、Linux ARM64 ZIPは69,490,929 bytes。
- 先行するLinux ARM64版はPi 4B実機のX11環境で起動・UI描画を確認済み。0.3.7配布物そのものの起動回帰、EcoLogger USB、Wayland、タッチ、長時間試験は未実施。

## 2026-09-04 / 0.3.6 UX250h準備版

- .NETコア/模擬USB 96チェック合格。実行時の自動CAN設定変更なし、明示取得コマンドの応答名、ハイブリッド0 rpm、欠測、デモ舵角を確認。
- Web単体9試験、公開Hostingを使ったブラウザ回帰に合格。Firebaseは合成応答に置換し、実際の地理院タイルを読込み。実Firebaseへの試験位置書込みはなし。
- Windows自己完結EXEのスモーク合格。13画面、UX車種・デモ・取得設定、DEMO時の車両コマンド無効化、車載CANなし設定の保存を確認。画面画像を目視確認。
- Windows x64 / Linux ARM64 ZIPのPE/ELF、同梱.NET 8、ZIP内容とSHA256を監査。Linux ARM実機上の起動は未検証。
- ロガーは不在。新ファームのUSB実通信、車両OBD、舵角の実測、耐久試験は明日の確認事項。
- 詳細は [UX250H_TEST.md](UX250H_TEST.md)。以下は旧版の履歴で、旧チェック数・旧schema・旧実機検証を新ファームの実機実績と混同しない。


## 0.3.5 ライブ共有・デモ/USB同等性

- Settingsを「共有リンクを作ってコピー」「データ共有をON」「ブラウザで確認」の3操作に整理。Firebase URL、共有ID、キーの入力欄は設けない。
- 受信フレームを1 Hzへ間引き、1リクエストで最新値と日別履歴を原子的に更新する。HTTP失敗は表示・SD記録から分離して再試行する。
- 7日分を残し、8日前の日を削除する。送信待ちは最大約1時間に制限する。
- スマホ画面はFirebase RESTのストリーミング接続で最新値を受信し、直近30分の走行経路を描く。
- デモを現行USB-OTGのschema revision 83・81チャンネル契約へ合わせ、デモと実機が同じ `TelemetryFrame` 以降の処理を通るようにした。
- .NETチェックで設定移行、URL制約、1 Hz間引き、デモ共有、実測／デモ属性のキュー保持、キーなしPATCH、履歴、閲覧URL、デモ運動の速度・距離整合、デモ/USBスキーマ同等性、既存機能を確認。
- Web 4チェックで共有URL ID、Firebase URL、ストリームイベントの解釈、経路グリッドの実距離目盛りを確認。
- Windows配布EXEそのものを起動し、39項目、全24画面画像、ライブ共有タブ、車載CANなし設定の保存を確認。
- Firebase Sparkへ更新後の閲覧ページを実配備。公開ページ上でUSB-OTG相当点（DEMOなし）を表示後、同じ接続のままデモ点（`DEMO · デモ検証`）へライブ更新できた。点内の属性と逆の古い共有メタを故意に置いても、点内の車体・DEMO属性を優先することを確認。
- 公開データベースへの匿名PATCH 204、共有ID配下の読出し、検証データの個別削除200、削除後のlatest/meta/historyがすべてnullであることを確認。
- デモの表示速度35～61 km/hに対して従来の円弧移動が約20～31 km/hだった不整合を修正。位置、積算距離、ヨー角速度、前後・左右加速度を同じ速度積分から生成する。

検証日：2026-09-02。Windows実装、UI、Linux用通信を対象とした卓上検証です。

## 実機条件

- EcoLogger：実装済みlogger_v1基板。既存の起動済みロガーを使用。
- ファーム表示：`2.17.0 / logger-v1-ecocapture-20260901k`。
- GNSS / IMU / SDを動作させ、車載CANとセンサCANは接続しない。
- アプリ接続：ネイティブUSB COM10。診断は既存書込み機のCOM8。
- UI試験の設定は専用フォルダーへ分離。ユーザーの設定や既存SDファイルは変更しない。
- Windows x64 / Godot 4.7.2 .NET / .NET 8。Windows GUI実行ファイルそのものを試験。

## 確認項目

| 区分 | 結果・内容 |
|---|---|
| コアとWindows通信 | 86チェック合格。81チャンネル疎配列、欠測、設定、位置、ラップ、水平補正行列、Solve解析、再接続、ライブ共有の点内属性、コマンドとテレメトリの同時処理 |
| Linux通信 | 67チェック合格。共通62項目に加え実Linux PTYで作成・読み書き・切断などを確認 |
| EXE実機UI | 39チェック合格。全5画面、Settings全5タブ、全4車種、CANなし、水平補正、SolveのSD一覧・取得・経路描画、実機/デモのschema revision 83・81チャンネル完全一致を確認 |
| Race | 手動ラップ、JSON/CSV保存、USB切断中の時間継続、速度の欠測表示、復帰、CANなしでのRPM非表示 |
| デモ | 明示切替、USB解放、実測との保存先分離、実測受信への復帰 |
| Maps | ワイド表示、標準横1 km、0.5 / 1 / 2 / 4 / 8 km、淡色／標準、オフラインキャッシュを確認 |
| IMU設定 | 前方と上方が同じ軸になる設定を拒否。静止データから補正行列を保存し、補正5チャンネルの実配信を確認 |
| Solve | SDの現行区間を安全にローテートして分割取得。CSV解析、平均／最高速度、距離、経路表示、赤線ホバー、画像レイヤーを確認 |
| 自動ラップ | 実機UIで待機状態を確認。通過方向、幅、時間補間、初回通過での開始、通信空白の排除は再現可能な入力で検証 |
| UI | 1280×800と小さいウィンドウで確認。全24画像の全画素が白黒または指定した赤だけであることを確認 |

自動ラップの実際のライン通過、および走行中のGNSS+IMU精度は、この卓上試験の対象外です。IMU補完は最大3秒の停止と10 Hzの低速移動時の方位確定もコア試験で確認しています。

## USB復帰とSD保護

接続処理単体を実EcoLoggerに45秒つなぎ、診断コマンドでネイティブUSBだけを3回外しました。

- 初回を含め4回接続、367サンプル受信、全367サンプルでIMU/SD正常。
- 不正フレーム0。約2.0〜2.6秒で受信復帰。
- SD記録は4,630行増加。SD欠落、SDエラー、IMUエラーの増加なし。
- 本体再起動なし。CAN listen-onlyを維持。

EXEのUI試験でもRace表示中にUSBだけを1回外し、計測が続くことを確認しました。デモ往復と手動再接続も確認しています。検証用UART操作は `testUsbReconnect` の `LOGGER_USB_ONLY` に限定しました。

最終配布EXE 0.3.5の39項目試験では、SDが4,911行増加し、SD欠落／SDエラー／IMUエラーの増加なし、本体再起動なし、CAN送受信なしでした。USBだけを一度切断して自動復帰し、実機→デモ→実機の切替後も受信を継続しました。試験中だけ水平補正を有効化し、終了時に元の設定へ戻したことも読戻しました。

## SD未挿入起動と後挿し

既存ファームを書き換えず、A105（COM8）とネイティブUSB（COM10）で実機確認しました。

- SDを安全クローズして抜去後、ENによる再起動を実施。約1 / 4 / 7 / 10 / 13 / 16秒以降も約3秒周期で `ESP_ERR_TIMEOUT (will retry; NEVER format)` を確認。
- SDなしでは `logging.status=0`、記録行0、ファイル名なし。並行してGPS、IMU、USB通信は正常で、IMU/GNSSエラー0。
- 電源とENを触らずSDを後挿し。次の再試行で `/sdcard/logs/20260902_025208_JST_LDCE75A88_0000.csv` を作成し、`logging.status=1`、1,287行まで増加。uptimeは継続しており再起動なし。
- その後の配布EXE試験終了時は8,474行、試験区間で4,911行増加。SDエラー・欠落・IMUエラーの追加なし。
- LOG LEDの論理条件（記録中のみ点灯）はソースと状態値で一致。SD後挿しで `logging.status=1`・記録行増加中に、基板上のLOG LED点灯を使用者が目視確認した。

これは電源を落とさないUSB detachの試験です。物理的な電源断、Windowsのスリープ復帰、ケーブルやハブ固有の障害までは確認していません。

## 性能と配布物

Windowsでの通常表示時の実測は `artifacts/runtime-performance/performance.json`、EXE全画面試験時の実測は `artifacts/exe-ui-accepted/verification.json` に保存しました。メモリ値にはGodotと同梱.NETが含まれます。CPUは論理1コアを100%とした値で、マシン全体の使用率ではありません。

各画面で5秒待機後、静止状態を約20秒測定しました。メモリは各プロセスの起動を含むピークWorking Setです。

| 画面 | メモリ | 通常表示のCPU（1コア比） |
|---|---:|---:|
| Home | 278.5 MiB | 4.3% |
| Indicate | 282.9 MiB | 7.2% |
| Maps | 284.2 MiB | 6.4% |

全画面切替、Solve取得・解析、デモ、地図取得、画面撮影を含む最終UI試験ではピークWorking Set 393.3 MiBでした。これは短時間の卓上測定で、長時間走行時の最大値を保証する数値ではありません。

設計は4 GB RAMを前提とし、受信履歴・地図取得・描画負荷を制限しています。詳細は [LINUX.md](LINUX.md)。Windowsでの性能をARM機の性能保証には使いません。

Windows x64 EXEと同梱ランタイム、Linux ARM64のELFと同梱ランタイムを出力しています。先行するLinux ARM64版はPi 4BのX11環境で起動・UI描画を確認済みです。0.3.7配布物そのもののPi 4起動回帰とEcoLogger USB、ROCK 5B実機は未検証です。

## 残る実環境確認

- 車載CANの実受信、各車種・型式・年式のID／換算の照合。
- 車体へ最終固定した状態での水平校正と振動の影響。
- 実コースでの自動ラップと移動時の地図／位置精度。
- Pi 4 / ROCK 5BのGPU、USB権限、4 GB構成での長時間動作。
- 電源断やOSスリープを含む運用試験。

これらを完了済みとは扱っていません。ファームは書込み済みです。GNSS OTP、回路、CAN送信設定、既存SDログは変更・消去していません。

## エビデンスの場所

- `artifacts/usb-reconnect/verification.json`：3回USB復帰とロガーの前後状態。
- `artifacts/demo-usb-equivalence/usb-bench-contract.json`：実USBのschema revision 83・81チャンネルとデモの一致、95/95正常サンプル。
- `artifacts/hardware-ui-0.3.5/hardware-ui.json`：配布EXE 0.3.5の39項目UIチェック結果。
- `artifacts/hardware-ui-0.3.5/verification.json`：SD/CAN/再起動・配色・性能・EXE SHA-256チェック。
- `artifacts/hardware-ui-0.3.5/*.png`：実機画面24枚。
- `artifacts/runtime-performance/performance.json`：通常表示の性能。
- `artifacts/export-windows-x64.log` / `artifacts/export-linux-arm64.log`：配布ビルド。
- `dist/SHA256SUMS.txt`：配布ZIPの照合値。

実測画像、地図キャッシュ、設定には位置情報が含まれるため、エビデンスはローカルに置き、ZIPやGitへ含めません。

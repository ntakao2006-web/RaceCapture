"""Sensor-only Podium NDJSON. No CAN frames, files, camera or replay queue."""
import asyncio
import json
import math
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from pydantic import BaseModel, ConfigDict, Field, model_validator
from models import CHANNELS

DEFAULT_CHANNELS = ['Lat','Lon','Altitude','GPSSpeed','Yaw','GPSFix','GPSSats',
                    'AccelX','AccelY','AccelZ','GyroX','GyroY','GyroZ','Roll','Pitch']
RANGES = {'Lat':(-90,90),'Lon':(-180,180),'Altitude':(-500,9000),
          'GPSSpeed':(0,300),'Speed':(0,300),'Yaw':(0,360),'GPSFix':(0,5),
          'GPSSats':(0,64),'RPM':(0,10000),'Throttle':(0,100),'WaterTemp':(-40,150),
          'BatteryVolt':(0,20)}

class PodiumConfig(BaseModel):
    model_config = ConfigDict(extra='forbid')
    enabled: bool = False
    hardware_ready: bool = False
    host: str = Field(default='telemetry.podium.live', pattern=r'^[A-Za-z0-9][A-Za-z0-9.-]{0,252}$')
    port: int = Field(default=8080, ge=1, le=65535)
    apn: str = Field(default='', pattern=r'^[A-Za-z0-9._-]{0,100}$')
    username: str = Field(default='', max_length=64)
    password: str = Field(default='', max_length=64, repr=False)
    device_id: str = Field(default='', max_length=128, repr=False)
    channels: list[str] = Field(default_factory=lambda:list(DEFAULT_CHANNELS), min_length=1, max_length=90)

    @model_validator(mode='after')
    def valid(self):
        if len(set(self.channels))!=len(self.channels):raise ValueError('Duplicate channels')
        if any(not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,31}',n) for n in self.channels):raise ValueError('ASCII names required')
        for s in (self.username,self.password):
            if any(ord(c)<32 or ord(c)>126 or c in '"\\' for c in s):raise ValueError('Invalid AT credentials')
        if any(ord(c)<33 or ord(c)>126 for c in self.device_id):raise ValueError('Invalid key')
        if self.enabled and not (self.hardware_ready and self.device_id and self.apn):raise ValueError('SIM, antenna, APN and key required')
        return self

class ConfigStore:
    def __init__(self,root):
        self.path=Path(root)/'private'/'podium.json'
        self.error=None
        try:self.config=PodiumConfig.model_validate_json(self.path.read_text()) if self.path.exists() else PodiumConfig()
        except (ValueError,OSError):self.config=PodiumConfig();self.error='保存設定を読めません。送信はOFFです。'
        self.revision=0

    def public(self):
        data=self.config.model_dump(exclude={'password','device_id'})
        data.update(key_configured=bool(self.config.device_id),password_configured=bool(self.config.password),error=self.error)
        return data

    def update(self,body,allowed):
        data=dict(body)
        clear_key=data.pop('clear_key',False);clear_password=data.pop('clear_password',False)
        data={**self.config.model_dump(),**data}
        if not data.get('device_id'):data['device_id']=self.config.device_id
        if not data.get('password'):data['password']=self.config.password
        if clear_key:data['device_id']=''
        if clear_password:data['password']=''
        config=PodiumConfig.model_validate(data)
        if not set(config.channels)<=set(allowed):raise ValueError('Unknown sensor')
        self.path.parent.mkdir(mode=0o700,exist_ok=True)
        os.chmod(self.path.parent,0o700)
        temp=self.path.with_suffix('.tmp')
        fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            os.fchmod(f.fileno(),0o600)
            json.dump(config.model_dump(),f,allow_nan=False);f.flush();os.fsync(f.fileno())
        temp.replace(self.path)
        self.config=config;self.revision+=1;self.error=None
        return self.public()

def line(data):
    return (json.dumps(data,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')

@dataclass(frozen=True)
class Sensor:
    name: str
    unit: str
    low: float
    high: float

def sensors(config,vehicle):
    custom={s.name:s.unit for s in vehicle.signals}
    result=[]
    for name in config.channels:
        if name not in CHANNELS and name not in custom:raise ValueError('Unknown sensor')
        unit=CHANNELS[name][1] if name in CHANNELS else custom[name]
        unit=unit.replace('°','deg').replace('²','^2')
        unit=unit.encode('ascii','replace').decode('ascii')
        low,high=RANGES.get(name,(-1000,1000))
        result.append(Sensor(name,unit,low,high))
    return result

class Encoder:
    def __init__(self,channels):self.channels=channels
    def auth(self,key):return line({'cmd':{'schemaVer':2,'auth':{'deviceId':key}}})
    def meta(self):
        return line({'s':{'meta':[{'nm':s.name,'ut':s.unit,'sr':10,'min':s.low,'max':s.high} for s in self.channels]}})
    def sample(self,sample):
        if not sample or sample.get('source')!='logger-v2-hardware' or sample.get('demo') is not False:return None
        values=[];masks=[0]*((len(self.channels)+31)//32)
        for i,ch in enumerate(self.channels):
            value=sample.get('values',{}).get(ch.name,sample.get('can_signals',{}).get(ch.name))
            if type(value) in (int,float) and math.isfinite(value):
                values.append(round(value,6));masks[i//32]|=1<<(i%32)
        return line({'s':{'d':values+masks}}) if values else None

class AuthenticationError(Exception):pass

class PodiumSender:
    def __init__(self,root,runtime):
        self.store=ConfigStore(root);self.runtime=runtime
        self.state={'state':'off','message':'LTE送信OFF','frames':0,'bytes':0,'reconnects':0,'skipped':0,'last_sent_age_ms':None}
        self.sent_at=0;self.blocked_revision=None

    def status(self):
        return {**self.state,'target_hz':10,'last_sent_age_ms':round((time.monotonic()-self.sent_at)*1000) if self.sent_at else None,
                'transport':'SIM7070G TCP / STM32 UART','configured':bool(self.store.config.device_id),'enabled':self.store.config.enabled}

    def set_state(self,name,message):self.state.update(state=name,message=message)

    async def session(self,transport,config,revision):
        encoder=Encoder(sensors(config,self.runtime.config))
        self.set_state('connecting','LTE回線へ接続中')
        await transport.connect(config)
        self.set_state('authenticating','Podium認証中')
        await transport.send(encoder.auth(config.device_id))
        response=json.loads(await transport.readline())
        if response.get('status')!='ok':raise AuthenticationError()
        await transport.send(encoder.meta())
        self.set_state('streaming','センサ値を送信中')
        fingerprint=[(c.name,c.unit,c.low,c.high) for c in encoder.channels]
        deadline=time.monotonic();last_seq=None
        while self.store.revision==revision:
            if self.runtime.sd.status.get('active'):
                raise ConnectionError('SD operation')
            updated=sensors(config,self.runtime.config)
            current=[(c.name,c.unit,c.low,c.high) for c in updated]
            if current!=fingerprint:
                encoder=Encoder(updated);await transport.send(encoder.meta());fingerprint=current
            now=time.monotonic();sample=self.runtime.sample
            fresh=sample is not None and now-self.runtime.received_at<.5
            payload=encoder.sample(sample) if fresh and sample['seq']!=last_seq else None
            if payload:
                await transport.send(payload)
                self.state['frames']+=1;self.state['bytes']+=len(payload);self.sent_at=time.monotonic();last_seq=sample['seq']
            else:self.state['skipped']+=1
            # Never build a backlog or burst historical samples after a slow send.
            deadline=max(deadline+.1,time.monotonic())
            await asyncio.sleep(max(0,deadline-time.monotonic()))

    async def run(self):
        from sim7070 import SIM7070
        retry=0;seen_revision=-1
        while True:
            config=self.store.config;revision=self.store.revision
            if revision!=seen_revision:retry=0;seen_revision=revision
            if not config.enabled:
                self.set_state('off','LTE送信OFF');await asyncio.sleep(.5);continue
            if self.blocked_revision==revision:
                self.set_state('auth_failed','認証失敗。送信キーを修正して保存してください。');await asyncio.sleep(.5);continue
            if not self.runtime.bridge or not self.runtime.status()['connected'] or self.runtime.sd.status.get('active'):
                self.set_state('waiting','MCU通信またはSD操作完了を待っています');await asyncio.sleep(.5);continue
            transport=SIM7070(self.runtime.bridge)
            try:
                await self.session(transport,config,revision)
                retry=0
            except AuthenticationError:
                self.blocked_revision=revision
            except asyncio.CancelledError:raise
            except Exception:
                # Modem responses / exceptions may contain key or carrier credentials.
                self.state['reconnects']+=1
                self.set_state('retry','LTEまたはPodiumへの接続に失敗。再接続を待っています。')
                retry=min(5,retry+1)
            finally:
                with __import__('contextlib').suppress(Exception):await transport.close()
            if retry:
                until=time.monotonic()+min(30,2**retry)
                while self.store.revision==revision and time.monotonic()<until:await asyncio.sleep(.2)

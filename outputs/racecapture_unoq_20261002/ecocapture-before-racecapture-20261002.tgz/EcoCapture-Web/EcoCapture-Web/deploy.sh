#!/bin/sh
# Run on UNO Q after copying this directory and the dummy sketch/libraries.
set -eu
cd /home/arduino/EcoCapture-Web
mkdir -p /home/arduino/ecocapture-v2-data
docker build --network=none -t ecocapture-web:0.1.0 .
docker run --rm --network=none --entrypoint python3 \
  -v "$PWD/test_server.py:/app/test_server.py:ro" ecocapture-web:0.1.0 /app/test_server.py
if docker container inspect ecocapture-web >/dev/null 2>&1; then
  docker stop -t 15 ecocapture-web
  docker rm ecocapture-web
fi
docker run -d --name ecocapture-web --restart unless-stopped \
  --user 1000:1000 --cap-drop=ALL --security-opt=no-new-privileges \
  -p 127.0.0.1:8080:8080 \
  -v /var/run/arduino-router.sock:/var/run/arduino-router.sock \
  -v /home/arduino/ecocapture-v2-data:/data \
  --log-opt max-size=5m --log-opt max-file=2 \
  ecocapture-web:0.1.0

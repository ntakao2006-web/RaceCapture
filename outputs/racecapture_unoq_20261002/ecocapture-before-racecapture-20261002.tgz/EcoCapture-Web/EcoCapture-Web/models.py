"""Versioned V2 configuration; channel names deliberately match EcoCapture where possible."""
import math
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class Signal(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    name: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_]{0,31}$")
    unit: str = Field(default="", max_length=16)
    can_id: int = Field(ge=0, le=0x1FFFFFFF)
    extended: bool = False
    byte_offset: int = Field(ge=0, le=7)
    data_type: Literal["uint8", "int8", "uint16", "int16", "uint32", "int32"] = "uint16"
    endian: Literal["little", "big"] = "little"
    scale: float = 1
    offset: float = 0

    @model_validator(mode="after")
    def valid_layout(self):
        if not self.extended and self.can_id > 0x7FF:
            raise ValueError("標準CAN IDは0x7FFまでです")
        width = int(self.data_type.removeprefix("uint").removeprefix("int")) // 8
        if self.byte_offset + width > 8:
            raise ValueError("信号が8バイトを超えています")
        return self

class Configuration(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schema: Literal[1] = 1
    device_name: str = Field(default="EcoLogger V2", min_length=1, max_length=48)
    profile: Literal["no-can", "demo-vehicle"] = "no-can"
    can_bitrate: Literal[125000, 250000, 500000, 1000000] = 500000
    signals: list[Signal] = Field(default_factory=list, max_length=64)

    @model_validator(mode="after")
    def unique_names(self):
        if len({s.name for s in self.signals}) != len(self.signals):
            raise ValueError("信号名が重複しています")
        return self

CHANNELS = {
    "Speed": ("車速", "km/h"), "GPSSpeed": ("GNSS速度", "km/h"), "RPM": ("回転数", "rpm"),
    "Throttle": ("スロットル", "%"), "BatteryVolt": ("バッテリー", "V"),
    "Lat": ("緯度", "°"), "Lon": ("経度", "°"), "Altitude": ("標高", "m"),
    "Yaw": ("方位", "°"), "GPSFix": ("測位状態", ""), "GPSSats": ("衛星数", ""),
    "GNSSHz": ("生成周期", "Hz"), "AccelX": ("加速度 X", "m/s²"), "AccelY": ("加速度 Y", "m/s²"),
    "AccelZ": ("加速度 Z", "m/s²"), "GyroX": ("角速度 X", "°/s"), "GyroY": ("角速度 Y", "°/s"),
    "GyroZ": ("角速度 Z", "°/s"), "Roll": ("ロール", "°"), "Pitch": ("ピッチ", "°"),
    "LongAccel": ("前後加速度", "g"), "LatAccel": ("左右加速度", "g"), "VertAccel": ("上下加速度", "g"),
    "Distance": ("累積距離", "km"), "WaterTemp": ("水温", "°C")
}

def validate_sample(value):
    if not isinstance(value, dict) or value.get("source") != "stm32-dummy" or value.get("demo") is not True or value.get("schema") != 1:
        raise ValueError("Unexpected MCU telemetry source/schema")
    for key in ("seq", "mcu_ms"):
        if type(value.get(key)) is not int or not 0 <= value[key] <= 0xFFFFFFFF:
            raise ValueError("Invalid MCU sequence/timestamp")
    values = value.get("values", {})
    if set(values) != set(CHANNELS) or any(type(x) not in (int, float) or not math.isfinite(x) for x in values.values()):
        raise ValueError("Invalid MCU channels")
    return value

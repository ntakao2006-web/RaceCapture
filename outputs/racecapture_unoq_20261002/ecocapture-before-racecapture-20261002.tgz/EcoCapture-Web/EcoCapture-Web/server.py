"""EcoLogger V2: STM32 Bridge -> local CSV + REST/WebSocket. No host-generated telemetry."""
import asyncio
import csv
import json
import os
import re
import shutil
import time
import uuid
from collections import deque
from contextlib import asynccontextmanager, suppress
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from models import CHANNELS, Configuration, validate_sample

ROOT = Path(os.environ.get("ECOCAPTURE_DATA", "/data"))
ROOT.mkdir(parents=True, exist_ok=True)
LOGS = ROOT / "demo-logs"
LOGS.mkdir(exist_ok=True)
CONFIG_PATH = ROOT / "config.json"
RESERVE_BYTES = 256 * 1024 * 1024


def atomic_json(path, data):
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())
    temp.replace(path)


class Recorder:
    def __init__(self):
        self.file = None
        self.writer = None
        self.name = None
        self.rows = 0
        self.started = None
        self.started_mono = None
        self.error = None
        self.last_sync = 0
        self.last_check = 0

    def start(self, config):
        if self.file:
            return
        if shutil.disk_usage(ROOT).free < RESERVE_BYTES:
            raise HTTPException(507, "内蔵ストレージの空き容量が不足しています")
        self.started = datetime.now(timezone.utc).isoformat()
        self.started_mono = time.monotonic()
        self.name = "DEMO_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_") + uuid.uuid4().hex[:8] + ".csv"
        self.rows = 0
        self.error = None
        atomic_json(LOGS / (self.name + ".meta.json"), {
            "schema": 1, "demo": True, "source": "stm32-dummy", "storage": "UNO Q internal eMMC",
            "started_utc": self.started, "config": config.model_dump(),
            "mcu_generation_hz": 50, "linux_poll_target_hz": 20,
            "clock": "host_utc is Linux reception time, not GNSS time; mcu_ms wraps at 2^32",
            "units": {k: unit for k, (_, unit) in CHANNELS.items()}, "state": "recording"
        })
        self.file = (LOGS / self.name).open("x", encoding="utf-8", newline="")
        self.writer = csv.writer(self.file)
        self.writer.writerow(["schema", "demo", "source", "host_utc", "seq", "mcu_ms", *CHANNELS])
        self.last_sync = time.monotonic()
        self.last_check = 0

    def append(self, sample):
        if not self.file:
            return
        now = time.monotonic()
        try:
            if now - self.last_check >= 1:
                self.last_check = now
                if shutil.disk_usage(ROOT).free < RESERVE_BYTES:
                    raise OSError("Storage reserve reached (256 MiB)")
            self.writer.writerow([1, 1, sample["source"], sample["host_utc"], sample["seq"], sample["mcu_ms"],
                                  *(sample["values"][k] for k in CHANNELS)])
            self.rows += 1
            if now - self.last_sync >= 1:
                self.file.flush()
                os.fsync(self.file.fileno())
                self.last_sync = now
        except OSError as exc:
            self.error = str(exc)
            self.stop()

    def stop(self):
        if not self.file:
            return
        file, self.file = self.file, None
        try:
            file.flush()
            os.fsync(file.fileno())
        except OSError as exc:
            self.error = str(exc)
        finally:
            file.close()
        try:
            path = LOGS / (self.name + ".meta.json")
            meta = json.loads(path.read_text())
            meta.update(state="error" if self.error else "closed", rows=self.rows,
                        ended_utc=datetime.now(timezone.utc).isoformat(), error=self.error)
            atomic_json(path, meta)
        except OSError as exc:
            self.error = str(exc)

    def status(self):
        return {"active": self.file is not None, "name": self.name, "rows": self.rows,
                "elapsed_s": time.monotonic() - self.started_mono if self.file else 0, "error": self.error}


class Runtime:
    def __init__(self):
        self.config_error = None
        try:
            self.config = Configuration.model_validate_json(CONFIG_PATH.read_text()) if CONFIG_PATH.exists() else Configuration()
        except (ValueError, OSError) as exc:
            self.config = Configuration()
            self.config_error = str(exc)
        self.sample = None
        self.received_at = 0
        self.received = 0
        self.bridge_errors = 0
        self.error = None
        self.resets = 0
        self.times = deque(maxlen=100)
        self.recorder = Recorder()

    def status(self):
        age = time.monotonic() - self.received_at if self.sample else None
        fresh = age is not None and age < 1.0
        duration = self.times[-1] - self.times[0] if len(self.times) > 1 else 0
        return {"device": self.config.device_name, "version": "0.1.0", "demo": True,
                "source": "stm32-dummy", "connected": fresh,
                "age_ms": round(age * 1000) if age is not None else None,
                "receive_hz": round((len(self.times) - 1) / duration, 1) if duration and fresh else 0,
                "mcu_generation_hz": 50, "poll_target_hz": 20, "received": self.received,
                "bridge_errors": self.bridge_errors, "mcu_resets": self.resets, "error": self.error,
                "config_error": self.config_error, "storage": "internal-emmc",
                "storage_free_bytes": shutil.disk_usage(ROOT).free,
                "sensors": {"can": "not-connected", "gnss": "not-connected", "imu": "not-connected", "camera": "not-connected", "sd": "not-connected"},
                "logging": self.recorder.status()}

    def envelope(self):
        status = self.status()
        return {"type": "telemetry", "status": status, "sample": self.sample if status["connected"] else None}

    async def collect(self):
        from arduino.app_utils import Bridge
        while True:
            tick = time.monotonic()
            try:
                raw = await asyncio.to_thread(Bridge.call, "ecologger.read", timeout=1)
                sample = validate_sample(json.loads(raw))
                if self.sample is None or sample["seq"] != self.sample["seq"] or sample["mcu_ms"] != self.sample["mcu_ms"]:
                    if self.sample and sample["seq"] < self.sample["seq"]:
                        self.resets += 1
                    sample["host_utc"] = datetime.now(timezone.utc).isoformat()
                    self.sample = sample
                    self.received_at = time.monotonic()
                    self.times.append(self.received_at)
                    self.received += 1
                    self.recorder.append(sample)
                self.error = None
            except Exception as exc:
                self.error = str(exc)
                self.bridge_errors += 1
                await asyncio.sleep(0.5)
            await asyncio.sleep(max(0, 0.05 - (time.monotonic() - tick)))


runtime = Runtime()


@asynccontextmanager
async def lifespan(app):
    # Incomplete sessions remain downloadable and are explicitly marked after a restart.
    for path in LOGS.glob("*.csv.meta.json"):
        try:
            meta = json.loads(path.read_text())
            if meta.get("state") == "recording":
                meta["state"] = "interrupted"
                atomic_json(path, meta)
        except (ValueError, OSError):
            pass
    task = asyncio.create_task(runtime.collect())
    yield
    task.cancel()
    with suppress(asyncio.CancelledError):
        await task
    runtime.recorder.stop()


app = FastAPI(title="EcoLogger V2 / EcoCapture-Web", lifespan=lifespan)


def same_origin(origin, host):
    return urlparse(origin).netloc == host


@app.middleware("http")
async def local_requests(request: Request, call_next):
    if request.method in {"POST", "DELETE", "PUT"}:
        origin = request.headers.get("origin")
        if origin and not same_origin(origin, request.headers.get("host")):
            return JSONResponse({"detail": "別のサイトからの操作は受け付けません"}, status_code=403)
        if request.headers.get("x-ecocapture") != "1":
            return JSONResponse({"detail": "操作ヘッダーが必要です"}, status_code=403)
        if int(request.headers.get("content-length", "0")) > 65536:
            return JSONResponse({"detail": "設定が大きすぎます"}, status_code=413)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"
    return response


@app.get("/api/status")
def status():
    return runtime.status()


@app.get("/api/telemetry")
def telemetry():
    return runtime.envelope()


@app.get("/api/config")
def config():
    return runtime.config.model_dump()


@app.post("/api/config")
async def save_config(value: Configuration):
    if runtime.recorder.file:
        raise HTTPException(409, "設定を保存する前に記録を停止してください")
    atomic_json(CONFIG_PATH, value.model_dump())
    runtime.config = value
    runtime.config_error = None
    return {"config": value.model_dump(), "applied_to_can": False, "message": "設定を保存しました。CAN実機への適用は未実装です。"}


@app.get("/api/can/channels")
def channels():
    return {"signals": [s.model_dump() for s in runtime.config.signals], "hardware_connected": False, "applied": False}


@app.get("/api/channels")
def all_channels():
    return [{"name": key, "label": label, "unit": unit} for key, (label, unit) in CHANNELS.items()]


@app.post("/api/log/start")
async def start_log():
    if not runtime.status()["connected"]:
        raise HTTPException(409, "MCUからの受信を確認してから記録を開始してください")
    runtime.recorder.start(runtime.config)
    return runtime.recorder.status()


@app.post("/api/log/stop")
async def stop_log():
    runtime.recorder.stop()
    return runtime.recorder.status()


def log_path(name):
    if not re.fullmatch(r"DEMO_[0-9]{8}T[0-9]{6}Z_[0-9a-f]{8}\.csv", name):
        raise HTTPException(400, "不正なファイル名です")
    path = LOGS / name
    if not path.is_file() or path.is_symlink():
        raise HTTPException(404, "ログが見つかりません")
    return path


@app.get("/api/logs")
def list_logs():
    result = []
    for path in sorted(LOGS.glob("DEMO_*.csv"), reverse=True):
        stat = path.stat()
        result.append({"name": path.name, "size": stat.st_size, "modified_utc": datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(),
                       "active": runtime.recorder.file is not None and path.name == runtime.recorder.name, "demo": True})
    return result


@app.get("/api/logs/{name}/download")
def download(name: str):
    path = log_path(name)
    if runtime.recorder.file and runtime.recorder.name == name:
        raise HTTPException(409, "記録停止後にダウンロードしてください")
    return FileResponse(path, media_type="text/csv", filename=name)


@app.get("/api/logs/{name}/metadata")
def metadata(name: str):
    path = log_path(name).with_suffix(".csv.meta.json")
    return FileResponse(path, media_type="application/json", filename=path.name)


@app.delete("/api/logs/{name}")
async def delete_log(name: str):
    path = log_path(name)
    if runtime.recorder.file and name == runtime.recorder.name:
        raise HTTPException(409, "記録中のログは削除できません")
    path.unlink()
    path.with_suffix(".csv.meta.json").unlink(missing_ok=True)
    return {"deleted": name}


@app.websocket("/ws")
async def websocket(ws: WebSocket):
    origin = ws.headers.get("origin")
    if origin and not same_origin(origin, ws.headers.get("host")):
        await ws.close(code=1008)
        return
    await ws.accept()
    try:
        while True:
            await asyncio.wait_for(ws.send_json(runtime.envelope()), timeout=2)
            await asyncio.sleep(0.05)
    except (WebSocketDisconnect, RuntimeError, asyncio.TimeoutError, OSError):
        pass


app.mount("/", StaticFiles(directory=Path(__file__).parent / "web", html=True), name="web")

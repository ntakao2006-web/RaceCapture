"""Run in the UNO Q image; isolated temporary storage and no hardware mutations."""
import csv
import importlib
import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient
from pydantic import ValidationError
from models import CHANNELS, Configuration, Signal, validate_sample


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        os.environ["ECOCAPTURE_DATA"] = self.temp.name
        import server
        self.s = importlib.reload(server)
        self.client = TestClient(self.s.app)
        self.headers = {"X-EcoCapture": "1"}

    def tearDown(self):
        self.s.runtime.recorder.stop()
        self.client.close()
        self.temp.cleanup()

    def sample(self):
        return {"schema": 1, "demo": True, "source": "stm32-dummy", "seq": 1, "mcu_ms": 20,
                "values": {k: 0 for k in CHANNELS}, "host_utc": "2026-09-06T00:00:00Z"}

    def connected(self):
        self.s.runtime.sample = self.sample()
        self.s.runtime.received_at = time.monotonic()

    def test_stale_data_cleared_and_no_disconnected_recording(self):
        self.connected()
        self.assertIsNotNone(self.client.get("/api/telemetry").json()["sample"])
        self.s.runtime.received_at -= 2
        self.assertIsNone(self.client.get("/api/telemetry").json()["sample"])
        self.assertEqual(self.client.post("/api/log/start", headers=self.headers).status_code, 409)

    def test_csv_lifecycle_active_protection_and_metadata(self):
        self.connected()
        response = self.client.post("/api/log/start", headers=self.headers)
        self.assertEqual(response.status_code, 200)
        name = response.json()["name"]
        self.s.runtime.recorder.append(self.sample())
        self.assertEqual(self.client.delete(f"/api/logs/{name}", headers=self.headers).status_code, 409)
        self.assertEqual(self.client.get(f"/api/logs/{name}/download").status_code, 409)
        self.assertEqual(self.client.post("/api/config", headers=self.headers, json=Configuration().model_dump()).status_code, 409)
        self.client.post("/api/log/stop", headers=self.headers)
        content = self.client.get(f"/api/logs/{name}/download").text
        rows = list(csv.DictReader(content.splitlines()))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["demo"], "1")
        self.assertEqual(rows[0]["source"], "stm32-dummy")
        meta = self.client.get(f"/api/logs/{name}/metadata").json()
        self.assertEqual(meta["state"], "closed")
        self.assertEqual(meta["rows"], 1)
        self.assertEqual(self.client.delete(f"/api/logs/{name}", headers=self.headers).status_code, 200)
        self.assertEqual(self.client.get(f"/api/logs/{name}/download").status_code, 404)

    def test_config_validation_and_persistence(self):
        data = Configuration().model_dump()
        data["signals"] = [{"name": "TestRPM", "can_id": 512, "byte_offset": 0, "scale": 0.25}]
        self.assertEqual(self.client.post("/api/config", headers=self.headers, json=data).status_code, 200)
        self.assertEqual(self.s.Runtime().config.signals[0].scale, 0.25)
        data["signals"][0]["can_id"] = 2048
        self.assertEqual(self.client.post("/api/config", headers=self.headers, json=data).status_code, 422)
        data["signals"][0]["can_id"] = 512
        data["signals"][0]["byte_offset"] = 7
        self.assertEqual(self.client.post("/api/config", headers=self.headers, json=data).status_code, 422)
        self.assertFalse(self.client.get("/api/can/channels").json()["applied"])

    def test_cross_origin_operations_rejected(self):
        self.assertEqual(self.client.post("/api/log/stop").status_code, 403)
        self.assertEqual(self.client.post("/api/log/stop", headers={**self.headers, "Origin": "https://untrusted.example"}).status_code, 403)
        self.assertEqual(self.client.post("/api/log/stop", headers={**self.headers, "Origin": "http://testserver"}).status_code, 200)

    def test_storage_full_stops_recorder(self):
        self.connected()
        self.s.runtime.recorder.start(Configuration())
        with patch.object(self.s.shutil, "disk_usage", return_value=type("Space", (), {"free": 0})()):
            self.s.runtime.recorder.append(self.sample())
        self.assertFalse(self.s.runtime.recorder.status()["active"])
        self.assertIn("reserve", self.s.runtime.recorder.error)

    def test_path_and_invalid_data_rejected(self):
        for name in ("../config.json", "/etc/passwd", "something.csv"):
            with self.assertRaises(Exception):
                self.s.log_path(name)
        good = self.sample()
        validate_sample(good)
        good["values"]["Speed"] = float("nan")
        with self.assertRaises(ValueError): validate_sample(good)
        with self.assertRaises(ValueError): validate_sample({"demo": False})
        with self.assertRaises(ValidationError): Signal(name="A", can_id=1, byte_offset=0, scale=float("inf"))


if __name__ == "__main__":
    unittest.main(verbosity=2)

# EcoCapture-Web 0.2.0 / EcoLogger V2

UNO Q上で動く実測ロガーです。IMU、GNSS、CANの値をSTM32が取得し、SDへ独立記録します。Linux側はWeb画面と内蔵eMMCのCSV記録を担当します。PCやブラウザで測定値を生成しません。

## 開く・記録する

USB接続後、`Open-EcoCapture-Web.ps1` を実行し、http://127.0.0.1:8080/ を開きます。既に転送設定がある場合はURLを開くだけです。

- 電源投入でSTM32のSD記録が始まります。Web側も初期設定ではCSVを自動記録します。
- Dashboardの「記録停止」で両方を停止し、Loggingの一覧から保存済みファイルをダウンロードします。
- eMMCのCSV、CANの生フレーム、メタデータを個別に取得できます。
- SDの `EL000001.BIN` などは元のIMU/GNSS/CANデータを含みます。SD一覧のダウンロードは記録停止後に行います。Web経由のSD転送には時間がかかります。
- `python sd_decode.py EL000001.BIN` でCSVとCAN JSONLへ変換できます。全ブロックのCRCと連番を確認し、破損はエラーにします。WindowsでもPython標準ライブラリだけで動きます。
- 保存済みCSVの「SDへコピー」はFAT32へコピーし、書き込んだセクタを読み戻して照合します。記録停止中だけ使用できます。SDの既存ファイルを自動で削除・フォーマットしません。

ブラウザを閉じても記録は続きます。LinuxのWebアプリを止めてもSTM32のSD記録は続きます。USBが唯一の給電元なので、ケーブルを抜くと電源も失われます。

## 測定・表示

IMUはBNO055、NDOF・100Hz。加速度、角速度、姿勢、四元数、校正状態と元レジスタを保存します。割り込みは高加速度イベントです。この個体のFW03.11にはデータ準備完了割り込みがないため、サンプル取得には100Hzタイマーを使います。車体軸への変換と取付後の校正は実車で確認してください。

GNSSはMAX-M10Mの4衛星系統・10Hz。192MHz用の永久設定はこの個体で適用済みで、通常起動や更新ではOTPへ書き込みません。アンテナなし・測位なしの場合、位置と速度は空欄にします。GNSSのiTOWとUTCを元データに残します。PPSの割り込みはIMUと同じEXTI1を使うため有効にしていません。

CAN1/2ともClassic CAN・受信専用です。125/250/500/1000kbpsを選択できます。通常動作で送信しません。Settingsの信号定義でID、標準/拡張、符号、バイト順、スケール等を指定できます。1秒以上届かない値は空欄になります。初期値は500kbps、車載CAN接続なし。CAN FD、高負荷の車両通信、実配線は現在のUSB接続では未検証です。

LTE送信は初期状態OFFです。SIM7070の内蔵TCPを使うPodiumクライアントと設定画面を追加しました。SIM・LTEアンテナ・APN・Podium送信キーを揃えてから、Settings → UNO Q → LTE / Podiumで送信を開始します。今回の実回線・Podium到達は未確認です。PPPは不要な構成で、Linux全体をLTEでオンラインにする機能はありません。TVSを外して復旧した状態なので、保護部品の交換は別途必要です。カメラは未接続です。

## 保存先・障害時

Linux: `/home/arduino/ecocapture-v2-data/logs` にCSV、CAN JSONL、メタデータ。1秒ごとにflush/fsyncし、空き256MiBを下回るとeMMC記録を停止します。再起動で中断されたCSVはメタデータを `interrupted` にします。設定は同データディレクトリの `config.json` です。

SD: 512バイトセクタのFAT32プライマリパーティションに対応します。1MiB単位で空き領域を予約し、`ELxxxxxx.BIN` を作成します。実測データは65,536バイトの待ち行列を通して専用スレッドが保存し、満杯で次ファイルへ切り替えます。既存ログを上書きする循環記録は行いません。カード満杯、連続した1MiBの空き不足ではSD記録エラーを表示し、eMMCの記録は継続します。ファイルサイズは1秒ごとに更新するため、突然の電源断では末尾約1秒がファイルに現れない可能性があります。

現在の怪しい16GBカードは既存の256MiB FAT32パーティションを使っています。全容量を使うには、必要なデータを退避して別途パーティションを準備してください。

ログの `host_utc` はLinux受信時刻、`mcu_ms` はMCU起動からの経過時間です。GNSS UTCは測位系の時刻情報で別項目です。欠落数はBridge用待ち行列とSD用待ち行列を区別して確認します。

## 更新・起動

WindowsからWebとMCUを両方更新:

```powershell
powershell -ExecutionPolicy Bypass -File .\EcoCapture-Web\Update-UNOQ.ps1 -Firmware
```

事前に記録を停止します。このインストール済みUNO QのArduino core、ライブラリ、Dockerベースイメージを使います。別の未セットアップ基板用のワンクリック環境構築ではありません。

UNO Q内での更新は `deploy.sh` と `build-mcu.sh`。ソースは `firmware/ecologger_v2`。MCUの実際の書き込み領域は64KiBなので、ビルドで不要シンボルを整理してサイズを検査します。Arduino RouterBridgeの更新スレッドのスタックを8192バイトへ修正し、RPC受信バッファを1024バイトへ拡張し、MCUとLinuxルーターを460800bpsへ揃えます。

`ecocapture-mcu-start.service` が起動時にMCUを開始し、`ecocapture-web-start.service` がルーターのソケット作成後にコンテナを再接続します。WebはUSB経由のローカル管理用です。閲覧専用サイトや公開リンクは既存の明示的な公開操作で使い、今回新たにインターネット公開はしていません。

診断結果と現在の検証範囲は `outputs/logger_v2_bench_20261001/production` を参照してください。
